# No-code AI Content Creator Agent — n8n Project (Analytics Vidhya Submission)

## What's included
- `n8n_workflow_template.json` — n8n workflow export (template). Import into n8n and configure credentials.
- `README.md` — this file (setup & explanation).
- `prompt_templates.md` — platform-specific prompts and reasoning.
- `sample_outputs.md` — sample runs (topic + generated LinkedIn, X, Blog).
- `workflow_screenshot.png` — screenshot of workflow.

## Objective
Automate end-to-end content creation (discover → research → generate platform-specific content → update sheet) using n8n, Tavily Search, and OpenAI.

## Google Sheet structure
Create a Google Sheet (Sheet1) with columns (header row):
`Topic | Status | LinkedIn_Post | X_Post | Blog_Summary | Published_Date`

Example row:
- Topic: "AI in Education"
- Status: "Pending"

## How to import & configure the workflow
1. Import `n8n_workflow_template.json` into your n8n instance:
   - In n8n UI, Workflows → Import from file → choose the JSON.
2. Replace placeholders:
   - `<YOUR_GOOGLE_SHEET_ID>` with your Google Sheet ID.
   - `<TAVILY_API_KEY>` with your Tavily API key (or set via Credential in n8n).
   - Configure OpenAI credentials in the OpenAI nodes (use your OpenAI API key or chosen LLM provider).
3. Validate each node:
   - Authorize Google Sheets node.
   - Test the HTTP Request node to Tavily and adjust response parsing in the Function node.
   - Test each OpenAI node with a single topic and inspect token usage.
4. Run the workflow manually or set a scheduler/cron trigger to run periodically.

## Prompt design summary
See `prompt_templates.md` for system and user prompts and prompt-engineering rationale per platform (LinkedIn, X, Blog).

## Sample input & outputs
See `sample_outputs.md`.

## Submission contents
- n8n workflow JSON
- README.md
- prompt_templates.md
- sample_outputs.md
- screenshot of workflow (workflow_screenshot.png)

## Notes & troubleshooting
- If Tavily returns lots of raw content, use the Function node to reduce it to a concise `research_summary` to save tokens when calling the LLM.
- Use a low temperature (0.2–0.4) for LinkedIn/blog to reduce hallucinations; 0.3–0.6 for X if you want more creative hooks.
- Logging: Add a "Write Binary File" or "Google Drive" node to persist generated copies or logs.
